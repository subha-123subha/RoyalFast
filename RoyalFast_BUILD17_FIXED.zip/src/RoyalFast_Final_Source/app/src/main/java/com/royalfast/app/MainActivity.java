package com.royalfast.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import android.text.*;
import android.net.Uri;
import android.content.Intent;
import java.util.*;
import com.google.firebase.auth.*;
import com.google.firebase.FirebaseException;
import com.google.firebase.firestore.*;

public class MainActivity extends Activity {
  LinearLayout root, content, productList;
  FirebaseFirestore db;
  FirebaseAuth auth;
  ArrayList<CartItem> cart = new ArrayList<>();
  ArrayList<Product> products = new ArrayList<>();
  EditText search;
  TextView status;

  static class Product { String id,name,category,description; int price,stock; Product(String i,String n,int p,int s,String c,String d){id=i;name=n;price=p;stock=s;category=c;description=d;} }
  static class CartItem { Product p; int qty; CartItem(Product p){this.p=p;qty=1;} }

  @Override public void onCreate(Bundle b){ super.onCreate(b); auth=FirebaseAuth.getInstance(); db=FirebaseFirestore.getInstance(); if(auth.getCurrentUser()==null) showLogin(); else showCustomer(); }
  TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.DKGRAY);t.setPadding(14,10,14,10);return t;}
  Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}

  void base(String title){
    root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(247,247,247));
    LinearLayout head=new LinearLayout(this);head.setPadding(10,8,10,8);head.setGravity(Gravity.CENTER_VERTICAL);head.setBackgroundColor(Color.rgb(17,17,17));
    ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.royal_fast_logo);head.addView(logo,new LinearLayout.LayoutParams(48,48));
    TextView brand=tv(title,21);brand.setTextColor(Color.WHITE);head.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
    if(auth.getCurrentUser()!=null){Button logout=btn("Logout");logout.setOnClickListener(v->{auth.signOut();showLogin();});head.addView(logout);}
    root.addView(head);
    content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
  }
  void nav(){ LinearLayout n=new LinearLayout(this);n.setPadding(3,3,3,3);String[] a={"Home","Cart","Orders"}; for(String x:a){Button b=btn(x);n.addView(b,new LinearLayout.LayoutParams(0,58,1));if(x.equals("Home"))b.setOnClickListener(v->showCustomer());if(x.equals("Cart"))b.setOnClickListener(v->showCart());if(x.equals("Orders"))b.setOnClickListener(v->showOrders());}root.addView(n); }

  void showLogin(){
    base("Royal Fast • Login");
    content.addView(tv("Mobile OTP Login",24));
    content.addView(tv("Enter your mobile number with country code.",15));
    EditText phone=new EditText(this);phone.setHint("+91XXXXXXXXXX");phone.setInputType(3);content.addView(phone);
    Button send=btn("Send OTP");content.addView(send);
    LinearLayout otpBox=new LinearLayout(this);otpBox.setOrientation(LinearLayout.VERTICAL);content.addView(otpBox);
    send.setOnClickListener(v->{String p=phone.getText().toString().trim();if(!p.startsWith("+91")||p.length()!=13){Toast.makeText(this,"Enter valid +91 mobile number",Toast.LENGTH_SHORT).show();return;}send.setEnabled(false);PhoneAuthOptions options=PhoneAuthOptions.newBuilder(auth).setPhoneNumber(p).setTimeout(60L,java.util.concurrent.TimeUnit.SECONDS).setActivity(this).setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
      public void onVerificationCompleted(PhoneAuthCredential c){auth.signInWithCredential(c).addOnSuccessListener(x->showCustomer());}
      public void onVerificationFailed(FirebaseException e){send.setEnabled(true);Toast.makeText(MainActivity.this,"OTP failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
      public void onCodeSent(String id,PhoneAuthProvider.ForceResendingToken t){otpBox.removeAllViews();otpBox.addView(tv("OTP sent. Enter the 6-digit code:",15));EditText code=new EditText(MainActivity.this);code.setInputType(2);otpBox.addView(code);Button verify=btn("Verify OTP");otpBox.addView(verify);verify.setOnClickListener(v2->{verify.setEnabled(false);PhoneAuthCredential c=PhoneAuthProvider.getCredential(id,code.getText().toString().trim());auth.signInWithCredential(c).addOnSuccessListener(x->showCustomer()).addOnFailureListener(e->{verify.setEnabled(true);Toast.makeText(MainActivity.this,"Invalid OTP",Toast.LENGTH_SHORT).show();});});}
    }).build();PhoneAuthProvider.verifyPhoneNumber(options);});
  }

  void showCustomer(){
    base("Royal Fast");content.addView(tv("Subhar Store • Satmile (Contai) 721401",15));
    search=new EditText(this);search.setHint("Search products...");content.addView(search);
    status=tv("Connecting to Royal Fast inventory...",14);content.addView(status);
    productList=new LinearLayout(this);productList.setOrientation(LinearLayout.VERTICAL);content.addView(productList);
    search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){renderProducts(s.toString());}public void afterTextChanged(Editable e){}});
    listenProducts();
    nav();
  }
  void listenProducts(){
    db.collection("products").addSnapshotListener((snap,e)->{if(e!=null){status.setText("Firebase error: "+e.getMessage());return;}products.clear();if(snap!=null)for(DocumentSnapshot d:snap.getDocuments()){String n=d.getString("name");if(n==null||n.trim().isEmpty())continue;Number p=d.get("price",Number.class),s=d.get("stock",Number.class);products.add(new Product(d.getId(),n,p==null?0:p.intValue(),s==null?0:s.intValue(),String.valueOf(d.getString("category")),String.valueOf(d.getString("description"))));}status.setText(products.size()+" live products from Firebase");renderProducts(search==null?"":search.getText().toString());});
  }
  void renderProducts(String q){if(productList==null)return;productList.removeAllViews();String x=q.trim().toLowerCase(Locale.ROOT);int count=0;for(Product p:products){if(!x.isEmpty()&&!p.name.toLowerCase(Locale.ROOT).contains(x))continue;count++;LinearLayout row=new LinearLayout(this);row.setPadding(8,6,8,6);row.setGravity(Gravity.CENTER_VERTICAL);LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.addView(tv(p.name+"  ₹"+p.price,17));info.addView(tv((p.category==null?"":p.category)+" • Stock: "+p.stock,13));row.addView(info,new LinearLayout.LayoutParams(0,-2,1));Button add=btn(p.stock>0?"ADD":"OUT OF STOCK");add.setEnabled(p.stock>0);add.setOnClickListener(v->addToCart(p));row.addView(add);productList.addView(row);}if(count==0)productList.addView(tv(products.isEmpty()?"No products are available in Firebase yet.":"No matching product.",16));}
  void addToCart(Product p){for(CartItem c:cart)if(c.p.id.equals(p.id)){c.qty++;Toast.makeText(this,"Quantity updated",Toast.LENGTH_SHORT).show();return;}cart.add(new CartItem(p));Toast.makeText(this,p.name+" added",Toast.LENGTH_SHORT).show();}

  void showCart(){base("My Cart");if(cart.isEmpty())content.addView(tv("Your cart is empty.",20));int total=0;for(CartItem c:cart){total+=c.p.price*c.qty;LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.addView(tv(c.p.name+" • ₹"+c.p.price+" × "+c.qty,16),new LinearLayout.LayoutParams(0,-2,1));Button minus=btn("−");minus.setOnClickListener(v->{c.qty--;if(c.qty<=0)cart.remove(c);showCart();});r.addView(minus);Button plus=btn("+");plus.setOnClickListener(v->{c.qty++;showCart();});r.addView(plus);content.addView(r);}content.addView(tv("Total: ₹"+total,21));EditText address=new EditText(this);address.setHint("Full delivery address");content.addView(address);Spinner pay=new Spinner(this);pay.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"COD","UPI","Card"}));content.addView(pay);Button place=btn("Place Real Order");place.setOnClickListener(v->placeOrder(address.getText().toString().trim(),pay.getSelectedItem().toString()));content.addView(place);nav();}
  void placeOrder(String address,String payment){if(cart.isEmpty()){Toast.makeText(this,"Cart is empty",Toast.LENGTH_SHORT).show();return;}if(address.isEmpty()){Toast.makeText(this,"Enter delivery address",Toast.LENGTH_SHORT).show();return;}ArrayList<Map<String,Object>> items=new ArrayList<>();int total=0;for(CartItem c:cart){Map<String,Object> m=new HashMap<>();m.put("productId",c.p.id);m.put("name",c.p.name);m.put("price",c.p.price);m.put("qty",c.qty);items.add(m);total+=c.p.price*c.qty;}Map<String,Object> order=new HashMap<>();order.put("userId",auth.getUid());order.put("items",items);order.put("total",total);order.put("address",address);order.put("paymentMethod",payment);order.put("status",payment.equals("UPI")?"PAYMENT_PENDING":"PLACED");order.put("createdAt",FieldValue.serverTimestamp());db.collection("orders").add(order).addOnSuccessListener(d->{String orderId=d.getId(); if(payment.equals("UPI")){ try{ Uri uri=Uri.parse("upi://pay?pa=9641492873-5@axl&pn=Subhar%20Store&am="+total+"&cu=INR&tn=Royal%20Fast%20Order%20"+orderId); Intent i=new Intent(Intent.ACTION_VIEW,uri); startActivity(Intent.createChooser(i,"Pay with UPI")); }catch(Exception ex){ Toast.makeText(this,"No UPI app found. Order saved as PAYMENT_PENDING.",Toast.LENGTH_LONG).show(); } } else { cart.clear(); Toast.makeText(this,"Order placed successfully • "+orderId,Toast.LENGTH_LONG).show(); showOrders(); }}).addOnFailureListener(e->Toast.makeText(this,"Order failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}

  void showOrders(){base("My Orders");content.addView(tv("Live order status",22));db.collection("orders").whereEqualTo("userId",auth.getUid()).orderBy("createdAt",Query.Direction.DESCENDING).addSnapshotListener((snap,e)->{if(e!=null){content.addView(tv("Order loading error: "+e.getMessage(),14));return;}if(snap==null||snap.isEmpty()){content.addView(tv("No orders yet.",17));return;}content.removeAllViews();content.addView(tv("Live order status",22));for(DocumentSnapshot d:snap.getDocuments()){String st=d.getString("status");Long total=d.getLong("total");content.addView(tv("Order #"+d.getId()+"\nStatus: "+(st==null?"PLACED":st)+"\nTotal: ₹"+(total==null?0:total),16));}});nav();}
}
