# Royal Fast — Final Android Project Starter

Brand: Royal Fast
Store: Subhar Store
Location: Satmile (Contai), West Bengal 721401
Support: 7507089165

Included in this Android project starter:
- Customer home, search, products, cart, checkout
- COD / UPI / Card selection and provided UPI QR asset
- Order status/tracking UI
- Admin dashboard UI
- Delivery partner UI
- Notification flow placeholders

Production integrations still required before a real release APK:
- Firebase Phone OTP + Authentication
- Firebase/Firestore or Supabase production database
- FCM push notifications
- Payment gateway merchant integration for UPI/Card
- Maps/location and live tracking
- Secure admin authentication/roles
- Backend order/inventory/refund APIs
- Signed release keystore and release build

Do not put payment secrets or Firebase service-account keys in the Android app.


UPI merchant ID configured for UPI intent: 9641492873-5@axl. For production payment verification and Card payments, connect a payment gateway (Razorpay/Cashfree/PayU) and verify payment server-side before marking an order paid.
