package com.royalfast.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;

public class MainActivity extends Activity {
  LinearLayout root, content;
  ArrayList<String> cart=new ArrayList<>();
  FirebaseFirestore db;
  String[] names={"Rice 5kg","Atta 5kg","Mustard Oil 1L","Milk 1L","Biscuits","Soap","Potato 1kg","Onion 1kg"};
  int[] prices={320,240,165,62,30,45,35,40};

  @Override public void onCreate(Bundle b){super.onCreate(b); db=FirebaseFirestore.getInstance(); showCustomer();}
  TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.DKGRAY);t.setPadding(14,12,14,12);return t;}
  Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
  void base(String title){
    root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(247,247,247));
    LinearLayout head=new LinearLayout(this);head.setPadding(14,12,14,12);head.setGravity(Gravity.CENTER_VERTICAL);head.setBackgroundColor(Color.rgb(17,17,17));
    ImageView logo=new ImageView(this);logo.setImageResource(com.royalfast.app.R.drawable.royal_fast_logo);head.addView(logo,new LinearLayout.LayoutParams(54,54));
    TextView brand=tv(title,22);brand.setTextColor(Color.WHITE);head.addView(brand,new LinearLayout.LayoutParams(-2,-2));root.addView(head);
    content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
  }
  void nav(){
    LinearLayout n=new LinearLayout(this);n.setPadding(4,4,4,4);String[] a={"Home","Cart","Orders","Admin","Delivery"};
    for(String x:a){Button b=btn(x);n.addView(b,new LinearLayout.LayoutParams(0,55,1));
      if(x.equals("Home"))b.setOnClickListener(v->showCustomer());
      if(x.equals("Cart"))b.setOnClickListener(v->showCart());
      if(x.equals("Orders"))b.setOnClickListener(v->showOrders());
      if(x.equals("Admin"))b.setOnClickListener(v->showAdmin());
      if(x.equals("Delivery"))b.setOnClickListener(v->showDelivery());
    }root.addView(n);
  }
  void showCustomer(){
    base("Royal Fast");content.addView(tv("Subhar Store • Satmile (Contai) 721401",15));
    EditText search=new EditText(this);search.setHint("Search products...");content.addView(search);
    LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);content.addView(grid);
    content.addView(tv("Loading products from Firebase...",14));
    loadProducts(grid);
    search.setOnEditorActionListener((v,action,event)->{filterProductViews(grid, search.getText().toString());return false;});
    search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){filterProductViews(grid,s.toString());}public void afterTextChanged(android.text.Editable e){}});
    content.addView(tv("🔐 Mobile + OTP  •  📍 Location  •  🔔 Notifications\n💳 UPI / Card / COD  •  📦 Live order status & tracking",15));nav();
  }
  void loadProducts(LinearLayout grid){
    db.collection("products").get().addOnSuccessListener(result->{
      grid.removeAllViews();
      if(result.isEmpty()){
        grid.addView(tv("No products found in Firebase.",16));
        addDemoProducts(grid);return;
      }
      for(DocumentSnapshot d: result.getDocuments()){
        String name=d.getString("name");
        if(name==null||name.trim().isEmpty()) continue;
        Number pn=d.get("price",Number.class);String price=pn==null?"0":String.valueOf(pn.intValue());
        Number sn=d.get("stock",Number.class);String stock=sn==null?"":(" • Stock: "+sn.intValue());
        addProductRow(grid,name,price,stock);
      }
      if(grid.getChildCount()==0) grid.addView(tv("Products exist, but the name field is empty.",16));
    }).addOnFailureListener(e->{
      grid.removeAllViews();
      grid.addView(tv("Firebase product loading failed: "+e.getMessage(),14));
      addDemoProducts(grid);
    });
  }
  void addProductRow(LinearLayout grid,String name,String price,String stock){
    LinearLayout row=new LinearLayout(this);row.setPadding(8,5,8,5);row.setTag(name.toLowerCase(Locale.ROOT));
    TextView p=tv(name+"   ₹"+price+stock,16);row.addView(p,new LinearLayout.LayoutParams(0,-2,1));
    Button add=btn("ADD");add.setOnClickListener(v->{cart.add(name);Toast.makeText(this,"Added to cart",Toast.LENGTH_SHORT).show();});row.addView(add);grid.addView(row);
  }
  void addDemoProducts(LinearLayout grid){for(int i=0;i<names.length;i++)addProductRow(grid,names[i],String.valueOf(prices[i]),"");}
  void filterProductViews(LinearLayout grid,String q){String x=q.trim().toLowerCase(Locale.ROOT);for(int i=0;i<grid.getChildCount();i++){View v=grid.getChildAt(i);Object tag=v.getTag();if(tag instanceof String)v.setVisibility(x.isEmpty()||((String)tag).contains(x)?View.VISIBLE:View.GONE);}}
  void showCart(){base("My Cart");content.addView(tv("🛒 Items: "+cart.size(),20));for(String x:cart)content.addView(tv("• "+x,16));content.addView(tv("Payment",18));Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"COD","UPI","Card"}));content.addView(sp);EditText ad=new EditText(this);ad.setHint("Delivery address");content.addView(ad);Button order=btn("Place Order");order.setOnClickListener(v->{if(cart.isEmpty())Toast.makeText(this,"Cart is empty",Toast.LENGTH_SHORT).show();else{cart.clear();Toast.makeText(this,"Order placed — notification sent",Toast.LENGTH_LONG).show();}});content.addView(order);ImageView qr=new ImageView(this);qr.setImageResource(R.drawable.upi_qr);content.addView(qr,new LinearLayout.LayoutParams(-1,300));nav();}
  void showOrders(){base("My Orders");content.addView(tv("📦 Order Tracking",21));content.addView(tv("Order #RF123456\n✅ Placed → 🏪 Confirmed → 📦 Packed → 🛵 Out for Delivery → ✅ Delivered",17));nav();}
  void showAdmin(){base("Royal Fast Admin");String s="🛠️ Admin Dashboard\n\n📦 Orders — Accept / Reject\n🛒 Products — Add / Edit / Delete\n💰 Price & Stock — Update\n🛵 Delivery Partner — Assign\n🎟️ Coupon / Offers\n📊 Sales Report\n💸 Refund / Cancellation\n👥 Customer Management\n🔔 Customer/Admin Notifications\n🚚 Delivery PIN, Minimum Order & Charge — Admin controlled";content.addView(tv(s,16));Button b=btn("Manage Products");b.setOnClickListener(v->Toast.makeText(this,"Admin product manager (Firebase product data is now connected)",Toast.LENGTH_LONG).show());content.addView(b);nav();}
  void showDelivery(){base("Royal Fast Delivery");content.addView(tv("🛵 Delivery Partner\n\nLogin → New Order → Pickup Location → Customer Address → OTP → Delivered\n\nPickup: Subhar Store, Satmile, Contai 721401",17));Button b=btn("Accept New Order");b.setOnClickListener(v->Toast.makeText(this,"Order accepted",Toast.LENGTH_SHORT).show());content.addView(b);content.addView(btn("Picked-up"));content.addView(btn("Delivered"));content.addView(tv("💰 Earnings: ₹0 (Demo)",17));nav();}
}
