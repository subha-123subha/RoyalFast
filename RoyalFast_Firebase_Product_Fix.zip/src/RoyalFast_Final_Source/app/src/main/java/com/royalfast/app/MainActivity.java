package com.royalfast.app;

import android.app.*;import android.os.*;import android.graphics.Color;import android.view.*;import android.widget.*;import java.util.*;
import com.google.firebase.firestore.*;

public class MainActivity extends Activity {
  LinearLayout root, content; ArrayList<String> cart=new ArrayList<>(); ArrayList<Product> products=new ArrayList<>();
  FirebaseFirestore db;
  String[] names={"Rice 5kg","Atta 5kg","Mustard Oil 1L","Milk 1L","Biscuits","Soap","Potato 1kg","Onion 1kg"};
  int[] prices={320,240,165,62,30,45,35,40};
  @Override public void onCreate(Bundle b){super.onCreate(b); db=FirebaseFirestore.getInstance(); showCustomer();}
  TextView tv(String s,int sp){ TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.DKGRAY);t.setPadding(14,12,14,12);return t; }
  Button btn(String s){ Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b; }
  void base(String title){ root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(247,247,247));
    LinearLayout head=new LinearLayout(this);head.setPadding(14,12,14,12);head.setGravity(Gravity.CENTER_VERTICAL);head.setBackgroundColor(Color.rgb(17,17,17));
    ImageView logo=new ImageView(this);logo.setImageResource(com.royalfast.app.R.drawable.royal_fast_logo);head.addView(logo,new LinearLayout.LayoutParams(54,54));
    TextView brand=tv(title,22);brand.setTextColor(Color.WHITE);head.addView(brand,new LinearLayout.LayoutParams(-2,-2)); root.addView(head); content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root); }
  void nav(){ LinearLayout n=new LinearLayout(this);n.setPadding(4,4,4,4); String[] a={"Home","Cart","Orders","Admin","Delivery"}; for(String x:a){Button b=btn(x);n.addView(b,new LinearLayout.LayoutParams(0,55,1)); if(x.equals("Home"))b.setOnClickListener(v->showCustomer()); if(x.equals("Cart"))b.setOnClickListener(v->showCart());if(x.equals("Orders"))b.setOnClickListener(v->showOrders());if(x.equals("Admin"))b.setOnClickListener(v->showAdmin());if(x.equals("Delivery"))b.setOnClickListener(v->showDelivery());} root.addView(n); }

  void showCustomer(){base("Royal Fast"); content.addView(tv("Subhar Store • Satmile (Contai) 721401",15));
    EditText search=new EditText(this);search.setHint("Search products...");content.addView(search);
    LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);content.addView(grid);
    content.addView(tv("Loading products from Firebase...",15));
    loadProducts(grid, search);
    content.addView(tv("🔐 Mobile + OTP  •  📍 Location  •  🔔 Notifications\n💳 UPI / Card / COD  •  📦 Live order status & tracking",15));nav(); }

  void loadProducts(LinearLayout grid, EditText search){
    db.collection("products").get().addOnSuccessListener(snapshot -> {
      grid.removeAllViews(); products.clear();
      for(DocumentSnapshot d:snapshot.getDocuments()){
        String name=d.getString("name"); if(name==null||name.trim().isEmpty()) continue;
        Long pr=d.getLong("price"); Long st=d.getLong("stock"); String cat=d.getString("category"); String desc=d.getString("description");
        products.add(new Product(name,pr==null?0:pr.intValue(),st==null?0:st.intValue(),cat,desc));
      }
      if(products.isEmpty()){grid.addView(tv("No products found in Firebase.",16));return;}
      Runnable render=()->{
        grid.removeAllViews(); String q=search.getText().toString().trim().toLowerCase(); int count=0;
        for(Product p:products){if(!q.isEmpty()&&!p.name.toLowerCase().contains(q))continue; final Product fp=p; LinearLayout row=new LinearLayout(this);row.setPadding(8,5,8,5); TextView t=tv(fp.name+"   ₹"+fp.price+"\nStock: "+fp.stock,16);row.addView(t,new LinearLayout.LayoutParams(0,-2,1));Button add=btn("ADD");add.setEnabled(fp.stock>0);add.setOnClickListener(v->{cart.add(fp.name);Toast.makeText(this,"Added to cart",Toast.LENGTH_SHORT).show();});row.addView(add);grid.addView(row);count++;}
        if(count==0)grid.addView(tv("No matching products.",16));
      };
      search.setOnEditorActionListener((v,a,e)->{render.run();return false;}); search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){render.run();}public void afterTextChanged(android.text.Editable e){}}); render.run();
    }).addOnFailureListener(e -> {grid.removeAllViews();grid.addView(tv("Firebase error: "+e.getMessage(),15));});
  }

  static class Product {String name,category,description;int price,stock;Product(String n,int p,int s,String c,String d){name=n;price=p;stock=s;category=c;description=d;}}
  void showCart(){base("My Cart");content.addView(tv("🛒 Items: "+cart.size(),20));for(String x:cart)content.addView(tv("• "+x,16));content.addView(tv("Payment",18));Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"COD","UPI","Card"}));content.addView(sp);EditText ad=new EditText(this);ad.setHint("Delivery address");content.addView(ad);Button order=btn("Place Order");order.setOnClickListener(v->{if(cart.isEmpty())Toast.makeText(this,"Cart is empty",Toast.LENGTH_SHORT).show();else {cart.clear();Toast.makeText(this,"Order placed — notification sent",Toast.LENGTH_LONG).show();}});content.addView(order);ImageView qr=new ImageView(this);qr.setImageResource(R.drawable.upi_qr);content.addView(qr,new LinearLayout.LayoutParams(-1,300));nav();}
  void showOrders(){base("My Orders");content.addView(tv("📦 Order Tracking",21));content.addView(tv("Order #RF123456\n✅ Placed → 🏪 Confirmed → 📦 Packed → 🛵 Out for Delivery → ✅ Delivered",17));nav();}
  void showAdmin(){base("Royal Fast Admin");String s="🛠️ Admin Dashboard\n\n📦 Orders — Accept / Reject\n🛒 Products — Add / Edit / Delete\n💰 Price & Stock — Update\n🛵 Delivery Partner — Assign\n🎟️ Coupon / Offers\n📊 Sales Report\n💸 Refund / Cancellation\n👥 Customer Management\n🔔 Customer/Admin Notifications\n🚚 Delivery PIN, Minimum Order & Charge — Admin controlled";content.addView(tv(s,16));Button b=btn("Manage Products");b.setOnClickListener(v->Toast.makeText(this,"Admin product manager (production backend required)",Toast.LENGTH_LONG).show());content.addView(b);nav();}
  void showDelivery(){base("Royal Fast Delivery");content.addView(tv("🛵 Delivery Partner\n\nLogin → New Order → Pickup Location → Customer Address → OTP → Delivered\n\nPickup: Subhar Store, Satmile, Contai 721401",17));Button b=btn("Accept New Order");b.setOnClickListener(v->Toast.makeText(this,"Order accepted",Toast.LENGTH_SHORT).show());content.addView(b);content.addView(btn("Picked-up"));content.addView(btn("Delivered"));content.addView(tv("💰 Earnings: ₹0 (Demo)",17));nav();}
}
